/*  FILE: fintech_ecomm_example_1.sql
 *
 *  INFO: This file contains the example of SQL script solving the below
 *  explained problem from fin-tech domain.
 *
 *  This is EXECUTABLE PostgreSQL script.
 *
 *  TASK: Find all the Contract IDs and the number of their active connections.
 *
 *  DETAILS: Connections between Contracts are activated and deactivated
 *  in "one-sided" manner. Every connection's status change is registered in
 *  separate row in the table. The Contract that initiated the change in the
 *  connection's status is called "owner_contract", and the other one is
 *  "partner_contract". Every contract can initiate any change in their existing
 *  connections statuses and/or create new connections. The lastest in time change
 *  is considered valid.
 */

/* 1ST STEP - create schema and tables */

      CREATE SCHEMA IF NOT EXISTS fintech_ecomm_examples;

      DROP TABLE IF EXISTS fintech_ecomm_examples.contract_connection CASCADE;

      CREATE TABLE fintech_ecomm_examples.contract_connection
      (
        id bigint NOT NULL,
        create_time timestamp without time zone NOT NULL,
        contract_status character varying(255) NOT NULL,
        owner_contract bigint,
        partner_contract bigint,
        CONSTRAINT contract_connection_pkey PRIMARY KEY (id)
      );

/* 2ND STEP - INSERT test cases */

/* 2.1) One contract ACTIVATED by the Owner  */

      INSERT INTO fintech_ecomm_examples.contract_connection (
        id, create_time, contract_status,
        owner_contract, partner_contract
      ) VALUES (
        nextval('hibernate_sequence'),'2016-01-01 05:00:00.001','ACTIVE',
        11111, 22222
      );

/* 2.2) ACTIVATE, DEACTIVATE and ACTIVATE by the Owner (ADA - OOO)*/

      INSERT INTO fintech_ecomm_examples.contract_connection (
        id, create_time, contract_status,
        owner_contract, partner_contract
      ) VALUES (
        nextval('hibernate_sequence'),'2016-01-01 05:00:00.001','ACTIVE',
        33333, 44444),
      (
        nextval('hibernate_sequence'),'2016-02-01 05:00:00.001','DEACTIVE',
        33333, 44444),
      (
        nextval('hibernate_sequence'),'2016-03-01 05:00:00.001','ACTIVE',
        33333, 44444
      );

/* 2.3) ACTIVATE by the Owner and then DEACTIVATE and ACTIVATE by the Partner (ADA - OPP)*/

      INSERT INTO fintech_ecomm_examples.contract_connection (
        id, create_time, contract_status,
        owner_contract, partner_contract
      ) VALUES (
        nextval('hibernate_sequence'),'2016-01-01 05:00:00.001','ACTIVE',
        55555, 66666),
      (
        nextval('hibernate_sequence'),'2016-02-01 05:00:00.001','DEACTIVE',
        66666, 55555),
      (
        nextval('hibernate_sequence'),'2016-03-01 05:00:00.001','ACTIVE',
        66666, 55555
      );

/* 2.4) ACTIVATED and then DEACTIVATED by the Owner and ACTIVATED by the Partner (ADA - OOP)*/

      INSERT INTO fintech_ecomm_examples.contract_connection (
        id, create_time, contract_status,
        owner_contract, partner_contract
      ) VALUES (
        nextval('hibernate_sequence'),'2016-01-01 05:00:00.001','ACTIVE',
        77777, 88888),
      (
        nextval('hibernate_sequence'),'2016-02-01 05:00:00.001','DEACTIVE',
        77777, 88888),
      (
        nextval('hibernate_sequence'),'2016-03-01 05:00:00.001','ACTIVE',
        88888, 77777);

/* 2.5) Activate by the Owner, then DEACTIVATE by the Partner and Activate by the Owner (ADA - OPO)*/

      INSERT INTO fintech_ecomm_examples.contract_connection (
        id, create_time, contract_status,
        owner_contract, partner_contract
      ) VALUES (
        nextval('hibernate_sequence'),'2016-01-01 05:00:00.001','ACTIVE',
        99999, 88888),
      (
        nextval('hibernate_sequence'),'2016-02-01 05:00:00.001','DEACTIVE',
        88888, 99999),
      (
        nextval('hibernate_sequence'),'2016-03-01 05:00:00.001','ACTIVE',
        99999, 88888);

/* 2.6) Activate by the Owner, then DEACTIVATE by the Partner (AD - OP) */

      INSERT INTO fintech_ecomm_examples.contract_connection (
        id, create_time, contract_status,
        owner_contract, partner_contract
      ) VALUES (
        nextval('hibernate_sequence'),'2016-01-01 05:00:00.001','ACTIVE',
        11111, 88888),
      (
        nextval('hibernate_sequence'),'2016-02-01 05:00:00.001','DEACTIVE',
        88888, 11111);

/* 2.7) Activate then DEACTIVATE by the Owner (AD - OO) */

      INSERT INTO fintech_ecomm_examples.contract_connection (
        id, create_time, contract_status,
        owner_contract, partner_contract
      ) VALUES (
        nextval('hibernate_sequence'),'2016-01-01 05:00:00.001','ACTIVE',
        33333, 77777),
      (
        nextval('hibernate_sequence'),'2016-02-01 05:00:00.001','DEACTIVE',
        33333, 77777
      );

/* 2.8) One more "Owner-initiated" to make aggregates more interesting */

      INSERT INTO fintech_ecomm_examples.contract_connection (
        id, create_time, contract_status,
        owner_contract, partner_contract
      ) VALUES (
        nextval('hibernate_sequence'),'2016-04-01 05:00:00.001','ACTIVE',
        33333, 88888
      );

/* 3RD STEP - SELECT query*/

/* 3.1) Using WITH clause prepare auxiliary statement "owner_partner_result"
with all Owner initiated status chages */

WITH owner_partner_result AS (

      SELECT
             owner_contract, partner_contract, contract_status, create_time
      FROM
            fintech_ecomm_examples.contract_connection
      --WHERE
            --owner_contract = 88888
            /* If we wanted to know stats for specific contract number*/

/* 3.2) Swap the results making the partner_contract appear as owner_contract.
Union both results. */

      UNION

      SELECT partner_contract as owner_contract,
             owner_contract as partner_contract, contract_status, create_time
      FROM
             fintech_ecomm_examples.contract_connection
      --WHERE
             --partner_contract = 88888
             /* If we wanted to know stats for specific contract number*/
      ),

/* 3.3) (From the auxiliary statement "owner_partner_result"
created by the previous UNION) SELECT the status changes made
in the latest point in time. */

results_with_max AS (

      SELECT
                owner_contract, partner_contract, max(create_time) AS maxtime
      FROM
                owner_partner_result opr

      GROUP BY
                owner_contract, partner_contract

      )

/* 3.4) JOIN table with max time and previously created "swaped owner" table
finding the records with max time and active status. */


SELECT
        res1.owner_contract AS ContractID,
        count (res1.create_time) AS ActiveConnections
FROM
        owner_partner_result res1

        JOIN results_with_max res2 ON res1.owner_contract  = res2.owner_contract
                                   AND res1.partner_contract = res2.partner_contract
                                   AND res1.create_time = res2.maxtime
WHERE
        res1.contract_status = 'ACTIVE'

GROUP BY
        res1.owner_contract

ORDER BY
        res1.owner_contract;

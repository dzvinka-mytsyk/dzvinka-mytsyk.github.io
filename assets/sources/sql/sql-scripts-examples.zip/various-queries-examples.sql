/*  FILE: various-queries-examples.sql
 *
 *  INFO: This file contains the example of SQL script solving the below
 *  explained tasks in order to demonstrate general PostgreSQL knowledge.
 *
 *  This is EXECUTABLE PostgreSQL (run scripts one by one
    and pay attention do dependancies mentioned in comments). */

/* 1ST STEP - create schema, custom type and tables */

      DROP SCHEMA IF EXISTS sql_queries_examples CASCADE;

      CREATE SCHEMA sql_queries_examples;

      DROP TYPE IF EXISTS location CASCADE;

      CREATE TYPE location AS ENUM ('France', 'UK', 'Ireland',
        'Denmark', 'Germany', 'US');

      DROP TABLE IF EXISTS sql_queries_examples.employees CASCADE;

      CREATE TABLE IF NOT EXISTS sql_queries_examples.employees
      (
        id bigint NOT NULL,
        name character varying(255) NOT NULL,
        surname character varying(255) NOT NULL,
        manager_id bigint,
        location location NOT NULL,
        employed timestamp without time zone NOT NULL,
        dismissed timestamp without time zone,
        salary bigint NOT NULL,
        CONSTRAINT employees_pkey PRIMARY KEY (id)
      );

/* 2ND STEP - INSERT data into employees table*/

      INSERT INTO sql_queries_examples.employees (
        id, name, surname, manager_id,
        location, employed, dismissed, salary
      ) VALUES
      (
        nextval('hibernate_sequence'),'James', 'Joyce', NULL,
        'Ireland', '2016-01-01 05:00:00.001', NULL, 580000),
      (
        nextval('hibernate_sequence'),'Marcel', 'Proust', NULL,
        'France', '2016-02-01 05:00:00.001', NULL, 540000),
      (
        nextval('hibernate_sequence'),'Søren', 'Kierkegaard', NULL,
        'Denmark','2016-03-01 05:00:00.001', NULL, 510000),
      (
        nextval('hibernate_sequence'),'Martin', 'Heidegger', NULL,
        'Germany', '2016-04-01 05:00:00.001', NULL, 850000),
      (
        nextval('hibernate_sequence'),'Jean-Paul', 'Sartre', NULL,
        'France', '2016-03-04 05:00:00.001', NULL, 350000),
      (
        nextval('hibernate_sequence'),'Samuel', 'Beckett', NULL,
        'Ireland', '2016-03-07 05:00:00.001', NULL, 850000),
      (
        nextval('hibernate_sequence'),'Virginia', 'Woolf', NULL,
        'UK', '2016-03-08 05:00:00.001', NULL, 550000),
      (
        nextval('hibernate_sequence'),'William', 'Faulkner', NULL,
        'US', '2016-03-02 05:00:00.001', NULL, 550000
      );

/* 3RD STEP - UPDATE with managers ids*/

    UPDATE
          sql_queries_examples.employees
    SET
          manager_id = (
            SELECT id
            FROM sql_queries_examples.employees
            WHERE name = 'Virginia' AND surname = 'Woolf')
    WHERE
          id = (
            SELECT id
            FROM sql_queries_examples.employees
            WHERE name = 'Samuel' AND surname = 'Beckett')
          OR salary < (
            SELECT salary
            FROM sql_queries_examples.employees
            WHERE name = 'Virginia' AND surname = 'Woolf');

    UPDATE
          sql_queries_examples.employees
    SET
          manager_id = (
            SELECT id
            FROM sql_queries_examples.employees
            WHERE name = 'Samuel' AND surname = 'Beckett')
    WHERE
            manager_id is NULL
            AND name <> 'Virginia' AND surname <> 'Woolf';

    SELECT * FROM sql_queries_examples.employees; -- for easy check

/* TASK 1 : demonstrate self JOIN */

/* 1.1 - list the name-pairs: manager's name and employee they are managing */

    SELECT
          CONCAT(' ',e2.name,' ',e2.surname,' from ', e2.location) as Manager
          , CONCAT(' ',e1.name,' ',e1.surname,' from ', e1.location) as Employee

    FROM
          sql_queries_examples.employees e1
                JOIN sql_queries_examples.employees e2
                      ON e1.manager_id = e2.id;

/* 1.2 - list the employees from the same location as Samuel Beckett */

    SELECT
          CONCAT(' ',e2.name,' ',e2.surname,' ')

    FROM
          sql_queries_examples.employees e1, sql_queries_examples.employees e2

    WHERE
          e1.location = e2.location
          AND e1.id <> e2.id
          AND e1.name = 'Samuel' AND e1.surname = 'Beckett';

/* TASK 2 : demonstrate subqueries and aggregates */

/* 2.1 - List the locations and employees from the locations where more then 1 employee works */

  SELECT location,
         array_to_string(array_agg(CONCAT(name,' ',surname)),', ') AS employees_names,
         count(id) as employees_total
    FROM sql_queries_examples.employees
   WHERE location IN
          (
            SELECT location
            FROM sql_queries_examples.employees
            GROUP BY location
            HAVING count(id)>1
          )
GROUP BY location;

 /* 2.2 - Determine the employees with salaries higher than average. */

  SELECT     CONCAT(name,' ',surname), salary
  FROM       sql_queries_examples.employees
  GROUP BY   name, surname, salary
  HAVING     salary > ( SELECT AVG(salary)
                        FROM sql_queries_examples.employees);

/* 2.3 - Determine 3rd highest salary using correlated subquery. */

  SELECT *
  FROM sql_queries_examples.employees e1
  WHERE (2) = (                               -- here formula is (N-1) for the n-th highest salary
                SELECT COUNT(DISTINCT(e2.salary))
                FROM sql_queries_examples.employees e2
                WHERE e2.salary > e1.salary);

/* 2.4 - Create new table with employees whose salaries are lower than the average. */

  DROP TABLE IF EXISTS sql_queries_examples.underpaid CASCADE;

  CREATE TABLE sql_queries_examples.underpaid
  (
    id bigint NOT NULL references sql_queries_examples.employees(id),
    CONSTRAINT underpaid_pkey PRIMARY KEY (id)
  );

  INSERT INTO sql_queries_examples.underpaid (id) (
              SELECT id
              FROM sql_queries_examples.employees
              WHERE salary < ( SELECT AVG(salary)
                               FROM sql_queries_examples.employees));

 -- and to demonstrate the results:
    SELECT *
    FROM   sql_queries_examples.underpaid;

 /* 2.5 - Create new table with list employees who get 3 lowest salaries. */

   DROP TABLE IF EXISTS sql_queries_examples.up_for_raise CASCADE;

   CREATE TABLE sql_queries_examples.up_for_raise
   (
     id bigint NOT NULL references sql_queries_examples.employees(id),
     CONSTRAINT up_for_raise_pkey PRIMARY KEY (id)
   );

   INSERT INTO sql_queries_examples.up_for_raise (id) (
               SELECT id
               FROM sql_queries_examples.employees
               WHERE salary IN ( SELECT DISTINCT salary
                                FROM sql_queries_examples.employees
                                ORDER BY salary ASC
                                LIMIT 3));

-- and to demonstrate the results:
   SELECT *
   FROM   sql_queries_examples.up_for_raise;

/* TASK 3 : demonstrate OUTER JOIN */

/* 3.1 - (ATTENTION! THIS SCRIPT BELOW DEPENDS ON THE SCRIPT FROM 2.5)
          List all employees not eligible for a raise (according to the "logic" of the task 2.5). */

    SELECT CONCAT(e.name,' ',e.surname)
    FROM  sql_queries_examples.employees e
          LEFT JOIN sql_queries_examples.up_for_raise r
          ON e.id = r.id
    WHERE r.id is NULL;

/* TASK 4 : demonstrate ariphmetic operations */

/* 4.1 - Calculate total amount of salaries if all employees get 10% raise and bonus in 100$. */

   SELECT ((SUM(salary))*1.10 + COUNT(id)*100) as grand_total
   FROM sql_queries_examples.employees;
